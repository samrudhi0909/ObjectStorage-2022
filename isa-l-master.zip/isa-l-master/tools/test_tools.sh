#!/usr/bin/env bash

function test_start()
{
        echo "entering test: $1"
}

function test_end()
{
        echo "leaving test: $1 status: $2"
}
